package com.ashishupreti.myform;

/**
 * Created by user on 5/24/2018.
 */

public class Pubvar {
    static String name="";
    static  String emailid="";
    static String password="";
    static String newpassword="";
    static String mobilenumber="";


}