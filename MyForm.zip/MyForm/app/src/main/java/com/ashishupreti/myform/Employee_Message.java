package com.ashishupreti.myform;

import android.content.Intent;
import android.database.sqlite.SQLiteDatabase;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.telephony.SmsManager;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import static com.ashishupreti.myform.EmpDao.InsertMessage;
import static com.ashishupreti.myform.MyApplication.dao;

public class Employee_Message extends AppCompatActivity {
   EmpDao dao;
     String message,phone,name,email,phone1;
    EditText text1,text2,text3,text4;
    Button b1,b2;
    SQLiteDatabase db;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.message);
        text1=(EditText)findViewById(R.id.text11);
        text2=(EditText)findViewById(R.id.text10);
        text3=(EditText)findViewById(R.id.text12);
        text4=(EditText)findViewById(R.id.text20);
        text1.setText(Pubvar.name);
        text2.setText(Pubvar.emailid);
        text3.setText(Pubvar.mobilenumber);
        b1=(Button)findViewById(R.id.b1);
        b2=(Button)findViewById(R.id.login);



        b2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(Employee_Message.this, MainActivity.class);
                startActivity(intent);
            }
        });




        phone1="8979979426";
        b1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                message=text4.getText().toString();
                phone=text3.getText().toString();
                name=text1.getText().toString();
                email=text2.getText().toString();



                message="Name= "+name+"\n"+"Email id="+email+"\n"+"Phone No= "+phone+"\n"+"Reason= "+message;
                SmsManager smsManager=SmsManager.getDefault();
                smsManager.sendTextMessage(phone1,null,message,null,null);
                //1st null is service center
                //2nd null is sent pending intent
                //3rd null is reciever pending intent

                String s1="0";
                UserModel u1=new UserModel();
                u1.setName(text1.getText().toString());
                u1.setEmailAddress(text2.getText().toString());
                u1.setMobileNumber(text3.getText().toString());
                u1.setMessage(text4.getText().toString());
                u1.setIsSend(s1);

                dao.saveMessage(u1);
                Toast.makeText(Employee_Message.this,"Message Send Successfully",Toast.LENGTH_SHORT).show();
               }

        });
    }

    protected void onStart() {
        // TODO Auto-generated method stub
        super.onStart();
        this.dao = MyApplication.dao;
        dao.open(EmpDao.WriteMode);
    }


}
