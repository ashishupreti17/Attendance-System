package com.ashishupreti.myform;

import android.content.Context;
import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.EditText;
import android.widget.FilterQueryProvider;
import android.widget.ImageButton;
import android.widget.ListView;
import android.widget.SimpleCursorAdapter;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;

import static com.ashishupreti.myform.R.id.listView;

public class Pendingg extends AppCompatActivity {
    ListView mylist;

   // SQLiteDatabase db;

    public Context ctx;


    TextView text1;
    ListView lv;
    EmpDao dao;
    Cursor cr;
    SimpleCursorAdapter adapter;
    EditText editText;
    Boolean check;
    private ListView mListView;
    ArrayList<String> alldata1;
    static Button notifCount;
    static int mNotifCount = 0;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_pending);
        mylist=(ListView)findViewById(R.id.listView3);


    }


    @Override
    protected void onStart() {
        // TODO Auto-generated method stub
        super.onStart();

        this.dao = MyApplication.dao;
        dao.open(EmpDao.ReadMode);

        cr = dao.getMessageData();

        //Toast.makeText(getApplicationContext(),"Cursor"+ cr,Toast.LENGTH_SHORT).show();

        adapter = new SimpleCursorAdapter(this, R.layout.employee_card, cr, new String[]{"_id", "Name", "email", "mobile_number","emp_message","IsSendd"}, new int[]{R.id.textid, R.id.name, R.id.textemail, R.id.textphone,R.id.textmessage,R.id.issenddd});
        mylist.setAdapter(adapter);
       // myList.setTextFilterEnabled(true);
        mylist.setOnItemClickListener(new AdapterView.OnItemClickListener() {

            @Override
            public void onItemClick(AdapterView<?> adapter, View view, int position,
                                    long id) {
                // TODO Auto-generated method stub
                Object o = cr.getString(cr.getColumnIndex("_id"));
                String str_text = o.toString();

                //i++;

                Integer intValue = Integer.parseInt(str_text);

                Intent in = new Intent(view.getContext(), MainActivity.class);

                in.putExtra("Postition",intValue);

                startActivity(in);


            }

        });

    }



       /* LayerDrawable icon = (LayerDrawable) item.getIcon();

        // Update LayerDrawable's BadgeDrawable
        Utils2.setBadgeCount(this, icon, 2);*/







}

