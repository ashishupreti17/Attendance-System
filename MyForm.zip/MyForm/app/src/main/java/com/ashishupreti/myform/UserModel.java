package com.ashishupreti.myform;



public class UserModel {


    private String Name;
    private String mobileNumber;
    private String emailAddress;
    private String password;
    private String message;
    private String IsSend;

    public String getName()
    {
        return Name;
    }

    public void setName(String Name) {this.Name = Name;}

    public String getMobileNumber() {
        return mobileNumber;
    }
    public String getMessage()
    {
        return message;

    }
    public void setMessage(String message)
    {
        this.message=message;

    }

    public String getIsSend() {
        return IsSend;
    }

    public void setIsSend(String isSend) {
        IsSend = isSend;
    }

    public void setMobileNumber(String mobileNumber) {
        this.mobileNumber = mobileNumber;
    }

    public String getEmailAddress() {
        return emailAddress;
    }

    public void setEmailAddress(String emailAddress) {
        this.emailAddress = emailAddress;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }



}
