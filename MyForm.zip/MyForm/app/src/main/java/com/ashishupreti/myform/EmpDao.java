package com.ashishupreti.myform;

/**
 * Created by user on 5/24/2018.
 */

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.SQLException;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteDatabase.CursorFactory;
import android.database.sqlite.SQLiteOpenHelper;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.util.Base64;
import android.util.Log;
import android.view.View;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.List;

public class EmpDao {
    public static final String DbName = "Leave";
    public static final String TableName = "Employee";
    public static final String TableMESSAGE = "Message";
    public static final String TableQuery = "create table Employee(_id integer primary key autoincrement, Name text ,email text , mobile_number text,password text,message text)";
    public static final String InsertMessage="create table Message(_id integer primary key autoincrement, Name text, email text, mobile_number text, emp_message text, IsSendd text)";

    public static final int DBVersion = 1;
    public static final int ReadMode = 1;
    public static final int WriteMode = 2;
    public static final String KEY_NAME = "Name";
    //public static final String KEY_LAST_NAME = "last_name";
    public static final String KEY_EMAIL = "email";
    public static final String KEY_PASSWORD = "password";
    public static final String KEY_MESSAGEISSEND="IsSendd";
    public static final String KEY_MESSAGE="emp_message";
    public static final String KEY_MOBILE_NUMBER = "mobile_number";


    Employee_Message employee_message=new Employee_Message();
    


    MyHelper helper;
    SQLiteDatabase db;
    Context context;


    public void open(int mode)
    {
        if(mode == ReadMode)
        {
            db = helper.getReadableDatabase();
        }
        else
        {
            db = helper.getWritableDatabase();
        }
    }
    public EmpDao(Context ctx)
    {
        context = ctx;
        helper  = new MyHelper(ctx, DbName, null, DBVersion);

    }
    public EmpDao open() throws SQLException {


        db = helper.getWritableDatabase();
        return this;
    }
    public void close() {
        if (helper != null) {
            helper.close();
        }
    }



    class MyHelper extends SQLiteOpenHelper
    {

        public MyHelper(Context context, String name, CursorFactory factory,
                        int version) {
            super(context, name, factory, version);
            // TODO Auto-generated constructor stub
        }

        @Override
        public void onCreate(SQLiteDatabase db) {
		/*	// TODO Auto-generated method stub

			Log.d("hello", "table created");
			String CREATE_TABLE_USERS = "CREATE TABLE " + TABLE_users + "("
					+ KEY_ID + " integer primary key autoincrement, "
					+ KEY_FIRST_NAME + " TEXT , "
					+ KEY_LAST_NAME + " TEXT , "
					+ KEY_EMAIL + " TEXT , "
					+ KEY_PASSWORD + " TEXT , "
					+ KEY_MOBILE_NUMBER + " TEXT )";
			//db = this.getWritableDatabase();


			db.execSQL(CREATE_TABLE_USERS);*/

            db.execSQL(TableQuery);
            db.execSQL(InsertMessage);


        }

        @Override
        public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
            // TODO Auto-generated method stub


        }

    }



    public void saveEmp(UserModel mUserModel) {
        // TODO Auto-generated method stub

        ContentValues values = new ContentValues();
        values.put(KEY_NAME, mUserModel.getName());
        Log.d("Hello", "Name"+mUserModel.getName());
        values.put(KEY_EMAIL, mUserModel.getEmailAddress());
        values.put(KEY_MOBILE_NUMBER, mUserModel.getMobileNumber());
        values.put(KEY_PASSWORD, mUserModel.getPassword());
        Log.d("Hello", "Valueinserted");
        // Inserting Row
        //getwritabledatabase() put database in writable from.
        //SQLiteDatabase db = this.getWritableDatabase();
        long id = db.insert(TableName, null, values);
        // Closing database connection
        //db.close();

        Toast.makeText(context, "Registered Successfully", Toast.LENGTH_LONG).show();
        Toast.makeText(context, "data is save at"+id, Toast.LENGTH_LONG).show();


    }
    public void saveMessage(UserModel userModel)
    {
        ContentValues values = new ContentValues();
        values.put(KEY_NAME, userModel.getName());
        Log.d("Hello", "Name"+userModel.getName());
        values.put(KEY_EMAIL, userModel.getEmailAddress());
        values.put(KEY_MOBILE_NUMBER, userModel.getMobileNumber());
        values.put(KEY_MESSAGE,userModel.getMessage());
        values.put(KEY_MESSAGEISSEND,userModel.getIsSend());
        long id = db.insert(TableMESSAGE, null, values);
        // Closing database connection
        //db.close();

        Toast.makeText(context, "Registered Successfully", Toast.LENGTH_LONG).show();
        Toast.makeText(context, "data is save at"+id, Toast.LENGTH_LONG).show();

        //values.put(KEY_PASSWORD, userModel.getPassword());

       // Log.d("Hello", "Valueinserted");




    }
    public Cursor getAll()
    {
        // TODO Auto-generated method stub
        Cursor cr = db.query(TableName, null, null, null, null,null,null);


        return cr;
    }


  public Cursor getAllData() {
        // TODO Auto-generated method stub
        Cursor cr = db.query(TableName, null, null, null, null, null, null);


        return cr;
    }
    public Cursor getMessageData()
    {
        Cursor cr=db.query(TableMESSAGE,null,null,null,null,null,null);
        return cr;
    }

   Boolean CheckUser() {
        Boolean status = false;
        try {
            String PostUser = "SELECT * FROM " + TableName + " WHERE email='" + Pubvar.emailid + "'";
            //SQLiteDatabase db = helper.getReadableDatabase();
            Cursor cursor = db.rawQuery(PostUser, null);
            String dpass = "";
            if (cursor.moveToFirst())
                do {

                    int fnameIndex = cursor.getColumnIndex(KEY_NAME);
                    Pubvar.name = cursor.getString(fnameIndex);
                    Log.d("Hello","Value"+Pubvar.name);

                    //Log.d("Hello","Value"+pubvar.lname);
                    int emailIndex = cursor.getColumnIndex(KEY_EMAIL);
                    Pubvar.emailid = cursor.getString(emailIndex);
                    Log.d("Hello","Value"+Pubvar.emailid);

                    int mobileIndex = cursor.getColumnIndex(KEY_MOBILE_NUMBER);
                    Pubvar.mobilenumber = cursor.getString(mobileIndex);
                    //Log.d("Hello","Value"+pubvar.mobilenumber);


                    int passwordIndex = cursor.getColumnIndex(KEY_PASSWORD);
                    dpass = cursor.getString(passwordIndex);
                    Log.d("Hello", "Value" + dpass);


                } while (cursor.moveToNext());

            if (Pubvar.password.equals(dpass)) {
                status = true;

            } else {
                status = false;
            }
        } catch (Exception ex) {
            Log.d("Hello", "Error while getting values" + ex);
        }
        return status;

    }

}

