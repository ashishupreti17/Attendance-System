package com.ashishupreti.myform;

import android.content.SharedPreferences;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;



import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class Registration extends AppCompatActivity {

    EditText text1, text2, text3, text4, text5;
    Button button1,button2;
    EmpDao dao;
    public static final String MY_PREFS_NAME = "MyPrefsFile";
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_registration);
        text1=(EditText)findViewById(R.id.name1);
        text2=(EditText)findViewById(R.id.email);
        text3=(EditText)findViewById(R.id.pass);
        text4=(EditText)findViewById(R.id.pass1);
        text5=(EditText)findViewById(R.id.mobile);

    }
   // @Override
    protected void onStart() {
        // TODO Auto-generated method stub
        super.onStart();
        this.dao = MyApplication.dao;
        dao.open(EmpDao.WriteMode);
    }
    public void onRegister(View view) {
        try {
            String name = text1.getText().toString();
            String EmailId = text2.getText().toString();
            String Password = text3.getText().toString();
            String ConfirmPassword = text4.getText().toString();
            String Number = text5.getText().toString();


            if ((Password.equals(ConfirmPassword))) {



                Toast.makeText(Registration.this, "Registered Successfully", Toast.LENGTH_SHORT).show();
                UserModel u1 = new UserModel();
                u1.setName(text1.getText().toString());
                u1.setEmailAddress(text2.getText().toString());
                u1.setPassword(text3.getText().toString());
                u1.setMobileNumber(text5.getText().toString());



                SharedPreferences.Editor editor = getSharedPreferences(MY_PREFS_NAME, MODE_PRIVATE).edit();
                editor.putString("name", text1.getText().toString());
                editor.apply();

                dao.saveEmp(u1);


            }
            else{
                Toast.makeText(Registration.this, " Password doesn't match with  Confirm Password ", Toast.LENGTH_SHORT).show();
            }


        }
        catch(Exception ex)
        {
            Toast.makeText(Registration.this, "error1" + ex, Toast.LENGTH_SHORT).show();
        }
    }
    void onBack(View view)
    {
        try{
            Intent intent = new Intent(Registration.this, MainActivity.class);
            startActivity(intent);
        }
        catch(Exception ex)
        {
            Toast.makeText(Registration.this, "Exception"+ex, Toast.LENGTH_SHORT).show();
        }

    }




}

