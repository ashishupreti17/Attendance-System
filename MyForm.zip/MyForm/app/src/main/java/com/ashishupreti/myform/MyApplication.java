package com.ashishupreti.myform;

/**
 * Created by user on 5/25/2018.
 */
import android.app.Application;

public class MyApplication extends Application {
    public static EmpDao dao;
    @Override
    public void onCreate() {
        // TODO Auto-generated method stub
        super.onCreate();

        dao = new EmpDao(getApplicationContext());
    }

}