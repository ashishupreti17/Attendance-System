package com.ashishupreti.myform;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import static com.ashishupreti.myform.MyApplication.dao;
import static com.ashishupreti.myform.R.id.text10;

public class MainActivity extends AppCompatActivity {
    String EmailId="";
    String Password="";

    EditText em,pass;
    Button login,register;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        em=(EditText)findViewById(text10);
        pass=(EditText)findViewById(R.id.pass);
        login=(Button)findViewById(R.id.login);
        register=(Button)findViewById(R.id.signup);

       login.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                logindata();
            }

        });
        register.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                onregister();
            }
        });
    }
    void onregister()
    {
        try {


            Intent intent = new Intent(MainActivity.this, Registration.class);
            startActivity(intent);
        } catch (Exception ex) {
            Toast.makeText(MainActivity.this, "error:" + ex, Toast.LENGTH_SHORT).show();
        }




    }

    void logindata()
    {
        try {
            String EmailId=em.getText().toString();
            String Password=pass.getText().toString();
            Pubvar.emailid=EmailId;
            Pubvar.password=Password;
            if(EmailId.equals("test@gmail.com")&&Password.equals("12345"))
            {
                Intent intent = new Intent(MainActivity.this, ManagerLogin.class);
                startActivity(intent);
            }
            else if(EmailId.equals("")||Password.equals(""))
            {
                Toast.makeText(MainActivity.this,"Cannot leave field blank",Toast.LENGTH_SHORT).show();
            }
            else {


                boolean b1=dao.CheckUser();
                if (b1==true) {
                    Toast.makeText(MainActivity.this,"Login Successfully",Toast.LENGTH_SHORT).show();
                    Intent intent = new Intent(MainActivity.this,Employee_Message.class);
                    startActivity(intent);
                } else {
                    Toast.makeText(MainActivity.this, "Invalid username or password", Toast.LENGTH_SHORT).show();
                }
            }
        }
        catch (Exception ex)
        {
            Toast.makeText(MainActivity.this, "error2" + ex, Toast.LENGTH_SHORT).show();
        }
      }
    }

